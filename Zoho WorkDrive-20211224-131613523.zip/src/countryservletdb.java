//package Assegnment2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import org.json.JSONObject;  
import org.json.JSONArray;

public class countryservletdb {
	public static JSONObject dbconnection(String name) throws Exception {
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/wourld";
		
		String Username="root";		
		
		String Pass="";
		
		Connection con=DriverManager.getConnection(url, Username, Pass);
		
		Statement st=con.createStatement();
		
		String getvalue="select Name from country where Continent='"+name+"'";
		
		ResultSet answers=st.executeQuery(getvalue);
				
		JSONObject ob=new JSONObject();
		 JSONArray arr=new JSONArray();		
		while(answers.next()){
				arr.put(answers.getString(1));	
		}	
		ob.put("CountryName",arr);	
		
		answers.close();
		st.close();
		con.close();
		return ob;
	}	

}

