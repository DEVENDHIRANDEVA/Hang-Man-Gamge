function _(id){
			return document.getElementById(id);
		}
var letter=["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
for(var i=0;i<letter.length;i++){
_("lettersbox").innerHTML +="<div class='let' id='letter"+letter[i]+"' onclick='checkletter(this)'>"+letter[i]+"</div>"
	}

var cluarr=["tamilan power","chikendinner","thalapathy","Temple of City","No Vowel But 'Y'","History","Dream Hero","Symbol of Love","Father Of Nation","Old Religious Book","lightning arrester","benjamin franklin"];
var arr=["kabaddi","pubg","vijay","Odisha","trysts","genghiskhan","abdhulkalam","tajmahal","mahathmaganthi","rikvedham"];
var randomarr=Math.round(Math.random()*(arr.length-1));
 var temp=arr[randomarr].toUpperCase();
	for(i=0;i<temp.length;i++){
		_("answer1").innerHTML +="<div class='randomlet' id='letters"+i+"' >_</div>";
		_("clu").innerText=cluarr[randomarr];
		}
	console.log(temp);
var count=9;
	_("savenum").innerText=count;
var nofletter=temp.length;
var playercorrectletter=0;		
var score;
var loseman=0;
var chekked=0;
var man=0;
function getKeyCode(e){
	//console.log(e.key);
	if(letter.indexOf(e.key.toUpperCase()) != -1){
		console.log()
		checkLetterNew(e.key.toUpperCase());
	}
}
function checkLetterNew(ltr){	
	var flag = false;
	for(var i=0;i<temp.length;i++){				
			if(temp[i]==ltr){							
						_("letters"+i).innerText=ltr;
						man++;
						chekked++;	
						_("letter"+ltr).style.backgroundColor="green";							
						_("bestnum").innerText=man;
						_("winningscorenum").innerText=man;
						flag=true;															
					}					
				}
			if(flag==false){
						_("letter"+ltr).style.backgroundColor="red";
						loseman++;
						designing();
						console.log(loseman);
						score=_("savenum").innerText=--count;	
				}
}
function winningchekking(){
	if(nofletter==chekked){
					_("correctans").innerText="correct answer="+temp;
					_("winning").style.transform="scale(1)";
					_("container").style.transform="scale(0)";					
					_("winning").style.backgroundColor="rgb(152, 222, 124)"
					winningplayAudio();
					  x.pause(); 				
					_("winningscorenum").innerText=nofletter;

	}
}winningchekking();

function designing(){
			if(loseman==1){_("thala").style.opacity="1";}
			if(loseman==2){_("eyes1").style.opacity="1";}
			if(loseman==3){_("eyes2").style.opacity="1";}
			if(loseman==4){_("muth").style.opacity="1";}
			if(loseman==5){_("body").style.opacity="1";	}
			if(loseman==6){_("hand1").style.opacity="1";}
			if(loseman==7){_("hand2").style.opacity="1";}
			if(loseman==8){_("lage1").style.opacity="1";}
			if(loseman==9){_("lage2").style.opacity="1";}
			if(loseman==9){
				_("winningscorenum").innerText=0;
					losing.play(); 
					x.pause(); 
					_("winning").style.transform="scale(1)";
					_("container").style.transform="scale(0)";
					_("winhead").innerText=" lose the game";
					_("winning").style.backgroundColor="rgb(230, 78, 113)";
					_("winimage").style.backgroundImage="url('losegif.gif')"
					_("correctans").innerText=("correct answer="+temp);

				_("thala").style.opacity="1";				
				_("eyes1").style.opacity="1";
				_("eyes2").style.opacity="1";
				_("muth").style.opacity="1";
				_("body").style.opacity="1";
				_("hand1").style.opacity="1";
				_("hand2").style.opacity="1";
				_("lage1").style.opacity="1";
				_("lage2").style.opacity="1";
		}						
				if(_("thala").style.opacity=="1"&&_("eyes1").style.opacity=="1"&&_("eyes2").style.opacity=="1"&&_("muth").style.opacity=="1"&&_("body").style.opacity=="1"&&_("hand1").style.opacity=="1"&&_("hand2").style.opacity=="1"&&_("lage1").style.opacity=="1"&&_("lage2").style.opacity=="1"){
					_("winningscorenum").innerText=0;
					losing.play(); 
					x.pause(); 
					_("winning").style.transform="scale(1)";
					_("container").style.transform="scale(0)";
					_("winhead").innerText=" lose the game";
					_("winning").style.backgroundColor="rgb(230, 78, 113)";
					_("winimage").style.backgroundImage="url('losegif.gif')"
					_("correctans").innerText=("correct answer="+temp);
					
		}
				if(count==0){
					//randomarr=Math.round(Math.random()*(arr.length-1));
					_("winningscorenum").innerText=0;
					losing.play(); 
					x.pause(); 
					_("winning").style.transform="scale(1)";
					_("container").style.transform="scale(0)";
					_("winhead").innerText=" lose the game";
					_("winning").style.backgroundColor="rgb(230, 78, 113)";
					_("winimage").style.backgroundImage="url('losegif.gif')"
					_("correctans").innerText=("correct answer="+temp);
					
				}
				
			
				if(checkWinner(temp)){
					_("correctans").innerText="correct answer="+temp;
					_("winning").style.transform="scale(1)";
					_("container").style.transform="scale(0)";					
					_("winning").style.backgroundColor="rgb(152, 222, 124)"
					winningplayAudio();
					  x.pause(); 				
					_("winningscorenum").innerText=temp.length;
				}
}
function checkletter(ele){						
		var element=ele.innerText.toUpperCase();
		console.log(element);		
		//var flag=false;		
		var letterindex=temp.indexOf(element);	
		checkLetterNew(element);	
		designing();		
		
}
var x =_("pattu"); 
function playAudio() { 
  x.play(); 
} 
function pauseAudio() { 
  x.pause(); 
}
var win =_("winingeffect"); 
function winningplayAudio() { 
  win.play(); 
} 
function winningpauseAudio() { 
 win.pause(); 
}
var losing =_("losingeffect"); 
function losingplayAudio() { 
  losing.play(); 
} 
function losingpauseAudio() { 
 losing.pause(); 
}
function letstart(){
			
		_("mainhome").style.transform="scale(0)";
		_("container").style.transform="scale(1)";
		playAudio();		
	}
function homepage(){
		location.reload()
		_("mainhome").style.transform="scale(1)";
		_("container").style.transform="scale(0)";
		pauseAudio();
	}
var temp2 = 0;
function checkWinner(word){
		for(var i=0;i<word.length;i++){
			if(_("letters"+i).innerText	 == "_"){
				return false;		
			}
			}
		return true;
}
function restart(){	
		_("container").style.transform="scale(1)";
		
		_("winning").style.transform="scale(0)";		
		win.pause(); 		
		}
function whatisthis(){
		_("container").style.transform="scale(0)";
		_("intro").style.transform="scale(1)";
		pauseAudio();
		}
function backfun(){
		_("container").style.transform="scale(1)";
		_("intro").style.transform="scale(0)";
		 playAudio();
		}
var sound=false;
function music(){	
		if(sound==false){
			console.log("hai");
			_("song").style.backgroundImage="url(index2.png)";	
			sound=true;
			pauseAudio();
			}
		else if(sound==true){
				console.log("hello")
				_("song").style.backgroundImage="url(index1.jpeg)";
					sound=false;
				 playAudio();	
			}	
	}

